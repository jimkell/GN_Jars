#!/bin/bash
#SBATCH -J IVP
#SBATCH --partition=p_grigorie_1
#SBATCH -N1
#SBATCH -n1
#SBATCH --mem=100000
#SBATCH --time=10:00:00

date
module load java
java -jar ivp_reads_proc.jar 3773_chr14_normal_062822.conf "0-108" & 
wait
java -jar ivp_cleanup.jar 3773_chr14_normal_062822.conf
date
