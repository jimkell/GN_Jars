
import os

def delete_files(direc):
    print(direc)
    filelist = [ f for f in os.listdir(direc)]
    for f in filelist:
        os.remove(os.path.join(direc, f))

def remove_dir(direc):
    os.rmdir(direc)

dir_list = ['bam', 'ref_subfiles', 'sam']
#dir_list = ['sam']

sample = '7441'
direc = sample + '_chr'
suffix1 = '_normal_062822/'
suffix2 = '_tumor_062822/'
jar_file = 'ivp_reads_proc.jar'
script_file = 'script.sh'
gff_prefix = 'ref_GRCh37.p13_top_level_num.gff3.'

display_config_file = 'display_config.conf'

config_tn_line1 = 'Project_Type=tumor-normal # Optional, entry of "tumor-normal" (no quotes) allows a second sample provided in the Additional_Project_path and Additional_Sample_Name fields below to be opened along with the selected tumor sample.' 
config_tn_line2_prefix = 'Additional_Project_path='
config_tn_line2_suffix =  ' # Required if Project_Type is tumor-normal. This sample data is required to contain data in the same coordinate ranges as the tumor sample.' 
config_tn_line3_prefix = 'Additional_Sample_Name='
config_tn_line3_suffix = ' # Required if Project_Type is tumor-normal.'

java_cmd = 'java -jar '
jar_name = 'vn_052722.jar'
version_suffix = '062822'
bat_version_suffix = '062822-0527'

chr_num_list = ['19']
#chr_num_list = ['4', '6', '7', '12', '13', '17']

for d in dir_list:
    for c in chr_num_list:
        delete_files(direc + c + suffix1 + d)
        remove_dir(direc + c + suffix1 + d)
        delete_files(direc + c + suffix2 + d)
        remove_dir(direc + c + suffix2 + d)

for c in chr_num_list:
    os.remove(direc + c + suffix1 + jar_file)
    os.remove(direc + c + suffix2 + jar_file)
    os.remove(direc + c + suffix1 + script_file)
    os.remove(direc + c + suffix2 + script_file)
    os.remove(direc + c + suffix1 + gff_prefix + c + '.txt')
    os.remove(direc + c + suffix2 + gff_prefix + c + '.txt')

# append tumor display_config files
for c in chr_num_list:
    file = open(direc + c + suffix2 + display_config_file, "a")
    file.write(config_tn_line1 + '\n')
    file.write(config_tn_line2_prefix + direc + c + suffix1 + config_tn_line2_suffix + '\n')  
    file.write(config_tn_line3_prefix + sample + '_normal' + config_tn_line3_suffix + '\n')
    file.close()

    bat_file = open(sample + '_' + 'chr' + c + '_tumor_' + bat_version_suffix + '.bat', "w")
    content = java_cmd + jar_name + ' ' + sample + '_' + 'chr' + c + '_tumor_' + version_suffix
    bat_file.write(content)
    bat_file.close()

for c in chr_num_list:
    os.remove(direc + c + suffix1 + direc + c + suffix1[:-1] + '.conf')
    os.remove(direc + c + suffix2 + direc + c + suffix2[:-1] + '.conf')
                    





    
