

sra_run_table_filename = 'SraRunTable_processed.csv'
names_file = 'junction_names.csv'
mapped_counts_file = 'Nature-Calu-3-mRNA-mapped_counts.txt'
data_file = 'mRNA_counts_mapped_reads.csv'

# hpi values from SRA Run Table
hpi_list = ['1', '2', '4', '12', '16', '24', '36']
junc_list = []
sample_hpi_dict = {}
junc_hpi_counts_dict = {}
hpi_read_count_dict = {}

# populate sample hpi dict
def proc_sra_run_table(filename, sample_hpi_dict):
    col_name_list = []
    # column names
    run_col_name = 'Run'
    treatment_col_name = 'treatment'
    # values used to select samples used in graph
    data_type = 'hpi'

    line_count = 0
    f = open(filename)
    lines = f.readlines()
    for line in lines:
        entries = line.rstrip().split(',')
        # get column indices
        if line_count == 0:
            for entry in entries:
                col_name_list.append(entry)
        # get data
        else:
            # filter data to get samples used
            sample = entries[col_name_list.index(run_col_name)]
            # entry contains a comma
            hpi_entry = entries[1 + col_name_list.index(treatment_col_name)]
            hpi_value = hpi_entry[1:-len(data_type) - 1]
            sample_hpi_dict[sample] = hpi_value

        line_count += 1
    
def proc_reads_file(filename, del_name):
    sample_dict = {}
    f = open(filename + '.txt')
    lines = f.readlines()
    for line in lines:
        if len(line) > 0:
            entries = line.split()
            # sample is first entry in line followed by . in most NCBI data
            sample = entries[0].split('.')[0]
            # mapping quality
            mq = entries[4]
            if int(mq) >= 30:
                if sample not in sample_dict:
                    sample_dict[sample] = 1
                else:
                    sample_dict[sample] += 1
    outfile_name = filename + '_sample_del_counts' + '.csv'
    outfile = open(outfile_name, "w")
    for i in sample_dict:
        outfile.write(i + ',' + str(sample_dict[i]) + '\n')
    f.close()
    outfile.close()
    proc_sample_del_counts_file(outfile_name, sample_hpi_dict, del_name, junc_hpi_counts_dict)

def proc_sample_del_counts_file(filename, sample_hpi_dict, del_name, junc_hpi_counts_dict):
    f = open(filename)
    lines = f.readlines()
    for line in lines:
        entries = line.rstrip().split(',')
        sample = entries[0]
        count = int(entries[1])
        hpi = sample_hpi_dict[sample]
        #print(hpi)

        if del_name in junc_hpi_counts_dict:
            hpi_counts_dict = junc_hpi_counts_dict[del_name]
            if hpi in hpi_counts_dict:
                hpi_counts_dict[hpi] += count
            else:
                hpi_counts_dict[hpi] = count
                junc_hpi_counts_dict[del_name] = hpi_counts_dict
        else:
            hpi_counts_dict = {}
            hpi_counts_dict[hpi] = count
            junc_hpi_counts_dict[del_name] = hpi_counts_dict
    f.close()

def proc_mapped_reads_file(filename, h, hpi_read_count_dict):
    total_count = 0
    f = open(filename)
    lines = f.readlines()
    for line in lines:
        count = int(line.rstrip())
        total_count += count
    hpi_read_count_dict[h] = total_count
    f.close()

proc_sra_run_table(sra_run_table_filename, sample_hpi_dict)
print(sample_hpi_dict)

# variable used to skip header of csv file
line_count = 0
f = open(names_file)
lines = f.readlines()
for line in lines:
    if line_count > 0:
        entries = line.rstrip().split(',')
        del_name = entries[0]
        # preserve order in junction names for graph
        junc_list.append(del_name)
        #print(del_name)
        for h in hpi_list:
            group = 'Nature-Calu-3_' + h + 'h_bwa/'
            group_abbr = 'Nature-Calu-3-mRNA-' + h + 'h'

            proc_mapped_reads_file(group + mapped_counts_file, h, hpi_read_count_dict)
            
            filename_del = group + group_abbr + '_' + del_name + '_bwa_bam'
            print(filename_del)
            proc_reads_file(filename_del, del_name)
            
    line_count += 1
f.close()

print(junc_hpi_counts_dict)
print(hpi_read_count_dict)

outfile_data = open(data_file, "w")
# write header 
for h in hpi_list:
    outfile_data.write(',' + h)
outfile_data.write('\n')
for j in junc_list:
    outfile_data.write(j)
    hpi_counts_dict = junc_hpi_counts_dict[j]
    for h in hpi_list:
        if h in hpi_counts_dict:
            count = hpi_counts_dict[h]
            outfile_data.write(',' + str(count))
        else:
            outfile_data.write(',' + '0')
    outfile_data.write('\n')
outfile_data.write('mapped reads')
for h in hpi_list:
    outfile_data.write(',' + str(hpi_read_count_dict[h]))
outfile_data.write('\n')

print(data_file + ' written')
outfile_data.close()








